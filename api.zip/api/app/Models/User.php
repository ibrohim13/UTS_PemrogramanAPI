// User.php (Model)
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class User extends Model
{
    protected $fillable = ['username', 'password', 'name'];

    public function contacts()
    {
        return $this->hasMany(Contact::class);
    }
}

// UserController.php (Controller)
namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;

class UserController extends Controller
{
    public function register(Request $request)
    {
        // Logic to register user
    }

    public function login(Request $request)
    {
        // Logic to login user
    }

    public function update(Request $request, $id)
    {
        // Logic to update user
    }

    public function getUser($id)
    {
        // Logic to get user
    }

    public function logout()
    {
        // Logic to logout user
    }
}
