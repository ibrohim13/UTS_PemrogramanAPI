// Contact.php (Model)
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Contact extends Model
{
protected $fillable = ['first_name', 'last_name', 'email', 'phone'];

public function user()
{
return $this->belongsTo(User::class);
}

public function addresses()
{
return $this->hasMany(Address::class);
}
}

// ContactController.php (Controller)
namespace App\Http\Controllers;

use App\Models\Contact;
use Illuminate\Http\Request;

class ContactController extends Controller
{
public function create(Request $request)
{
// Logic to create contact
}

public function update(Request $request, $id)
{
// Logic to update contact
}

public function getContact($id)
{
// Logic to get contact
}

public function search(Request $request)
{
// Logic to search contact
}

public function remove($id)
{
// Logic to remove contact
}
}