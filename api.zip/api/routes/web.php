<?php

use Illuminate\Support\Facades\Route;

// Import Controller
use App\Http\Controllers\UserController;
use App\Http\Controllers\ContactController;
use App\Http\Controllers\AddressController;

// Routing for User Controller
Route::post('/register', [UserController::class, 'register']);
Route::post('/login', [UserController::class, 'login']);
Route::put('/user/{id}', [UserController::class, 'update']);
Route::get('/user/{id}', [UserController::class, 'getUser']);
Route::post('/logout', [UserController::class, 'logout']);

// Routing for Contact Controller
Route::post('/contact', [ContactController::class, 'create']);
Route::put('/contact/{id}', [ContactController::class, 'update']);
Route::get('/contact/{id}', [ContactController::class, 'getContact']);
Route::get('/contacts', [ContactController::class, 'listContacts']);
Route::delete('/contact/{id}', [ContactController::class, 'remove']);

// Routing for Address Controller
Route::post('/address', [AddressController::class, 'create']);
Route::put('/address/{id}', [AddressController::class, 'update']);
Route::get('/address/{id}', [AddressController::class, 'getAddress']);
Route::get('/addresses', [AddressController::class, 'listAddresses']);
Route::delete('/address/{id}', [AddressController::class, 'remove']);
