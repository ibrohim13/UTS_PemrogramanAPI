// Address.php (Model)
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Address extends Model
{
protected $fillable = ['street', 'city', 'province', 'country', 'postal_code'];

public function contact()
{
return $this->belongsTo(Contact::class);
}
}

// AddressController.php (Controller)
namespace App\Http\Controllers;

use App\Models\Address;
use Illuminate\Http\Request;

class AddressController extends Controller
{
public function create(Request $request)
{
// Logic to create address
}

public function update(Request $request, $id)
{
// Logic to update address
}

public function getAddress($id)
{
// Logic to get address
}

public function list()
{
// Logic to list addresses
}

public function remove($id)
{
// Logic to remove address
}
}